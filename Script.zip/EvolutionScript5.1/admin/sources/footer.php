<?php
/**
 *
 * @ EvolutionScript FULL DECODED & NULLED
 *
 * @ Version  : 5.1
 * @ Author   : MTIMER
 * @ Release on : 2014-09-01
 * @ Website  : http://www.mtimer.net
 *
 **/

if (!defined("EvolutionScript")) {
	exit("Hacking attempt...");
}

echo "

</div>

	<div class=\"footer\">
    	<div  align=\"center\">Powered by EvolutionScript Version ";
echo $software['version'];
echo " Copyright &copy; 2010 - ";
echo date("Y");
echo " EvolutionScript.com</div>

        <div class=\"clear\"></div>
	</div>
</div>


</body>
</html>
    ";
?>