<?php
/**
 *
 * @ EvolutionScript FULL DECODED & NULLED
 *
 * @ Version  : 5.0
 * @ Author   : MTIMER
 * @ Release on : 2014-08-15
 * @ Website  : http://www.mtimer.net
 *
 **/

include INCLUDES . "plugins/phpfastcache/phpfastcache.php";
phpFastCache::setup("storage", "files");
phpFastCache::setup("path", INCLUDES . "cache/");
$cache = phpFastCache();
?>