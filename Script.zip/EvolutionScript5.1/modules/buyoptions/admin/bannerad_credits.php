<?php
/**
 *
 * @ EvolutionScript FULL DECODED & NULLED
 *
 * @ Version  : 5.1
 * @ Author   : MTIMER
 * @ Release on : 2014-09-01
 * @ Website  : http://www.mtimer.net
 *
 **/

if (!defined("EvolutionScript")) {
	exit("Hacking attempt...");
}

$credits = $db->fetchOne("SELECT credits FROM banner_price WHERE id=" . $order['item_id']);
addbannercredits($order['user_id'], $credits);
?>